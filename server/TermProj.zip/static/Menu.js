var Menu = function(config){
	this.menuName = config.menuName;
	this.mx = config.mx;
	this.my = config.my;
	this.mW = config.mW;
	this.mH = config.mH;
	this.menuColor = config.menuColor;
}
